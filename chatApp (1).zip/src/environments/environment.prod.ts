export const environment = {
  production: true,
  firebase: {
    apiKey: "AIzaSyAbStLF6gcxG-e7gOn2mckrnhK91IhXyro",
    authDomain: "chat-1ca42.firebaseapp.com",
    databaseURL: "https://chat-1ca42.firebaseio.com",
    projectId: "chat-1ca42",
    storageBucket: "chat-1ca42.appspot.com",
    messagingSenderId: "38063642438",
    appId: "1:38063642438:web:aa2152cc68acc89b437747",
    measurementId: "G-TFC7V7FDLB"
  }
};
