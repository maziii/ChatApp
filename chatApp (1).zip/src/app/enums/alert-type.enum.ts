export enum AlertType {
    Success = 'success',
    Danger = 'danger'
}


